export { FaqPage } from './FaqPage'
