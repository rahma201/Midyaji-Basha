export { ContactPage } from './ContactPage'
